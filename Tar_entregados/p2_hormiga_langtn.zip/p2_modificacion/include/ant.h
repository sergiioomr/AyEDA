/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Algoritmos y Estructuras de Datos Avanzadas
 * 
 * @file ant.h
 * @author Sergio Molina Ríos (alu0101718194@ull.edu.es)
 * @date 2026-02-04
 * @brief This file declarates the Ant class. 
 * 				That class will be use to represent the Ant in the Tape.
 * 				Will be an abstract class. The method step is an pure virtual one, every ant_x must be define their unique behavior.
 */
#ifndef ANT_H
#define ANT_H

#include <iostream>
#include <utility>
#include "../include/tape.h"
#include "../include/enum_class.h"



class Ant {
	public:
	// Constructors
		Ant() : direction_{0}, position_{} {} // Default
		Ant(const Direction& direction, const std::pair<int, int>& position) : direction_(direction), position_(position) {}

	// Getters
		Direction GetDirection() const { return direction_; } 
		std::pair<int, int> GetPosition() const { return position_; }

	// Must be a pure virtual method to make the Ant class an abstract one
		virtual void Step(const Color &color) = 0;

	// Pure virtual method to get the ant type identifier as a string
		virtual std::string GetType() const = 0;

	// Virtual destructor to avoid memory leaks if we delete an object ant_x
		virtual ~Ant() = default;

	protected:
	// Functions to use in Step. 
		void TurnLeft();
		void TurnRight();
		void Move();

	private:	
		Direction direction_;
		// The ant current location
		std::pair<int, int> position_;		
};

std::ostream &operator<<(std::ostream& os, const Ant& ant);

#endif //ANT_H